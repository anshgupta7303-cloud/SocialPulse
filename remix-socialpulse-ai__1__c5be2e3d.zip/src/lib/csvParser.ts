import {
  PostMetricData,
  PostFormat,
  CSVColumnMapping,
  CSVValidationError,
  CSVImportResult,
} from '../types/index.ts';
import {
  calculateEngagementRate,
  calculateShareRate,
  calculateSaveRate,
} from './metrics.ts';

/**
 * Pure RFC4180-compliant CSV string tokenizer (no dependencies).
 */
export function parseCSVText(text: string): { headers: string[]; rows: string[][] } {
  const records: string[][] = [];
  let currentRow: string[] = [];
  let currentField = '';
  let inQuotes = false;
  let i = 0;

  while (i < text.length) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (inQuotes) {
      if (char === '"') {
        if (nextChar === '"') {
          // Escaped quote: ""
          currentField += '"';
          i += 2;
          continue;
        } else {
          // Closing quote
          inQuotes = false;
          i++;
          continue;
        }
      } else {
        currentField += char;
        i++;
        continue;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
        i++;
        continue;
      } else if (char === ',') {
        currentRow.push(currentField.trim());
        currentField = '';
        i++;
        continue;
      } else if (char === '\r' || char === '\n') {
        if (char === '\r' && nextChar === '\n') {
          i += 2;
        } else {
          i++;
        }
        currentRow.push(currentField.trim());
        currentField = '';
        if (currentRow.some((c) => c.length > 0)) {
          records.push(currentRow);
        }
        currentRow = [];
        continue;
      } else {
        currentField += char;
        i++;
        continue;
      }
    }
  }

  // Push remainder
  if (currentField.length > 0 || currentRow.length > 0) {
    currentRow.push(currentField.trim());
    if (currentRow.some((c) => c.length > 0)) {
      records.push(currentRow);
    }
  }

  if (records.length === 0) {
    return { headers: [], rows: [] };
  }

  const headers = records[0];
  const rows = records.slice(1);
  return { headers, rows };
}

/**
 * Automatically guesses default column mappings from common header names.
 */
export function guessColumnMapping(headers: string[]): CSVColumnMapping {
  const findMatch = (candidates: string[]): string => {
    const lowerHeaders = headers.map((h) => h.toLowerCase().trim());
    for (const cand of candidates) {
      const idx = lowerHeaders.findIndex(
        (h) => h === cand || h.includes(cand) || cand.includes(h)
      );
      if (idx !== -1) return headers[idx];
    }
    return '';
  };

  return {
    date: findMatch(['date', 'publish_date', 'timestamp', 'posted_at', 'day']),
    caption: findMatch(['caption', 'text', 'post_title', 'description', 'title']),
    topic: findMatch(['topic', 'category', 'pillar', 'tag']),
    format: findMatch(['format', 'media_type', 'type', 'content_type']),
    reach: findMatch(['reach', 'accounts_reached', 'reach_count']),
    impressions: findMatch(['impressions', 'total_views', 'views_total']),
    views: findMatch(['views', 'video_views', 'plays', 'reel_views']),
    likes: findMatch(['likes', 'like_count']),
    comments: findMatch(['comments', 'comment_count']),
    shares: findMatch(['shares', 'share_count']),
    saves: findMatch(['saves', 'save_count', 'bookmarks']),
    externalPostId: findMatch(['external_post_id', 'post_id', 'shortcode', 'media_id', 'postid', 'id']),
    hook: findMatch(['hook', 'headline', 'intro']),
    callToAction: findMatch(['call_to_action', 'cta', 'action']),
    profileVisits: findMatch(['profile_visits', 'profile_views']),
    follows: findMatch(['follows', 'new_followers', 'follower_gain']),
  };
}

/**
 * Validates and transforms parsed rows into PostMetricData array.
 * Strictly verifies date formats and numeric fields.
 * Rules:
 * - Empty cells or missing columns become null, NOT 0.
 * - If date is missing or invalid, row is invalid.
 * - If both caption and externalPostId are missing, row is invalid.
 * - Duplicates matched by externalPostId or (date + caption) are skipped.
 */
export function validateAndTransformCSV(
  headers: string[],
  rows: string[][],
  mapping: CSVColumnMapping,
  existingPosts: Partial<PostMetricData>[] = []
): CSVImportResult {
  const errors: CSVValidationError[] = [];
  const validRows: Partial<PostMetricData>[] = [];
  let skippedDuplicates = 0;

  const getColIndex = (headerName: string | undefined): number => {
    if (!headerName) return -1;
    return headers.findIndex((h) => h === headerName);
  };

  const dateIdx = getColIndex(mapping.date);
  const captionIdx = getColIndex(mapping.caption);
  const topicIdx = getColIndex(mapping.topic);
  const formatIdx = getColIndex(mapping.format);
  const reachIdx = getColIndex(mapping.reach);
  const impressionsIdx = getColIndex(mapping.impressions);
  const viewsIdx = getColIndex(mapping.views);
  const likesIdx = getColIndex(mapping.likes);
  const commentsIdx = getColIndex(mapping.comments);
  const sharesIdx = getColIndex(mapping.shares);
  const savesIdx = getColIndex(mapping.saves);
  const externalPostIdIdx = getColIndex(mapping.externalPostId);
  const hookIdx = getColIndex(mapping.hook);
  const ctaIdx = getColIndex(mapping.callToAction);
  const profileVisitsIdx = getColIndex(mapping.profileVisits);
  const followsIdx = getColIndex(mapping.follows);

  const mappedIndices = [
    dateIdx,
    captionIdx,
    topicIdx,
    formatIdx,
    reachIdx,
    impressionsIdx,
    viewsIdx,
    likesIdx,
    commentsIdx,
    sharesIdx,
    savesIdx,
    externalPostIdIdx,
    hookIdx,
    ctaIdx,
    profileVisitsIdx,
    followsIdx,
  ].filter((idx) => idx !== -1);

  const unmappedColumns = headers.filter((_, idx) => !mappedIndices.includes(idx));

  // Build seen key set for duplicate detection
  const seenKeys = new Set<string>();

  // Add existing posts into duplicate tracking
  for (const post of existingPosts) {
    if (post.externalPostId) {
      seenKeys.add(`id:${post.externalPostId.trim().toLowerCase()}`);
    }
    if (post.date && post.caption) {
      seenKeys.add(`content:${post.date.trim()}|${post.caption.trim().toLowerCase()}`);
    }
  }

  rows.forEach((row, rowIndex) => {
    const rowNum = rowIndex + 2; // Row 1 is header
    let rowHasError = false;

    // 1. Validate Date (must be provided and parseable, do NOT invent date)
    let parsedDate = '';
    if (dateIdx === -1) {
      errors.push({
        row: rowNum,
        field: 'date',
        value: '',
        message: 'Date column is not mapped.',
      });
      rowHasError = true;
    } else {
      const dateVal = row[dateIdx]?.trim() || '';
      if (!dateVal) {
        errors.push({
          row: rowNum,
          field: 'date',
          value: '',
          message: 'Date is required.',
        });
        rowHasError = true;
      } else {
        const timestamp = Date.parse(dateVal);
        if (isNaN(timestamp)) {
          errors.push({
            row: rowNum,
            field: 'date',
            value: dateVal,
            message: `Invalid date format "${dateVal}". Expected ISO (YYYY-MM-DD) or standard date string.`,
          });
          rowHasError = true;
        } else {
          parsedDate = new Date(timestamp).toISOString().split('T')[0];
        }
      }
    }

    // 2. Validate Caption & externalPostId
    const rawCaption = captionIdx !== -1 && row[captionIdx] ? row[captionIdx].trim() : '';
    const rawExternalId = externalPostIdIdx !== -1 && row[externalPostIdIdx] ? row[externalPostIdIdx].trim() : '';

    if (!rawCaption && !rawExternalId) {
      errors.push({
        row: rowNum,
        field: 'caption',
        value: '',
        message: 'Row must have at least a caption or an externalPostId.',
      });
      rowHasError = true;
    }

    // Helper for validating numeric metric fields: missing / empty -> NULL (never 0)
    const parseMetricNumber = (
      val: string | undefined,
      fieldName: string
    ): number | null => {
      if (val === undefined || val === null) {
        return null;
      }
      const trimmed = val.trim();
      if (trimmed === '' || trimmed.toLowerCase() === 'n/a' || trimmed === '-') {
        return null;
      }

      const cleaned = trimmed.replace(/,/g, '');
      const num = Number(cleaned);
      if (isNaN(num)) {
        errors.push({
          row: rowNum,
          field: fieldName,
          value: val,
          message: `Non-numeric metric "${val}" for ${fieldName}. Must be a valid number or "n/a".`,
        });
        rowHasError = true;
        return null;
      }
      if (num < 0) {
        errors.push({
          row: rowNum,
          field: fieldName,
          value: val,
          message: `${fieldName} cannot be negative (${num}).`,
        });
        rowHasError = true;
        return null;
      }
      return num;
    };

    // 3. Validate Numeric Delivery and Engagement Fields
    const reach = reachIdx !== -1 ? parseMetricNumber(row[reachIdx], 'reach') : null;
    const impressions = impressionsIdx !== -1 ? parseMetricNumber(row[impressionsIdx], 'impressions') : null;
    const views = viewsIdx !== -1 ? parseMetricNumber(row[viewsIdx], 'views') : null;

    // Missing engagement cells must remain null, NOT default to 0
    const likes = likesIdx !== -1 ? parseMetricNumber(row[likesIdx], 'likes') : null;
    const comments = commentsIdx !== -1 ? parseMetricNumber(row[commentsIdx], 'comments') : null;
    const shares = sharesIdx !== -1 ? parseMetricNumber(row[sharesIdx], 'shares') : null;
    const saves = savesIdx !== -1 ? parseMetricNumber(row[savesIdx], 'saves') : null;

    // Optional metrics
    const profileVisits = profileVisitsIdx !== -1 ? parseMetricNumber(row[profileVisitsIdx], 'profileVisits') : null;
    const follows = followsIdx !== -1 ? parseMetricNumber(row[followsIdx], 'follows') : null;

    const hook = hookIdx !== -1 && row[hookIdx] ? row[hookIdx].trim() : null;
    const callToAction = ctaIdx !== -1 && row[ctaIdx] ? row[ctaIdx].trim() : null;
    const topic = topicIdx !== -1 && row[topicIdx] && row[topicIdx].trim().length > 0 ? row[topicIdx].trim() : null;

    // Format normalization
    let format: PostFormat = 'reel';
    if (formatIdx !== -1 && row[formatIdx]) {
      const rawFormat = row[formatIdx].toLowerCase().trim();
      if (rawFormat.includes('carousel') || rawFormat.includes('album')) format = 'carousel';
      else if (rawFormat.includes('image') || rawFormat.includes('photo') || rawFormat.includes('post')) format = 'static_image';
      else if (rawFormat.includes('story')) format = 'story';
      else format = 'reel';
    }

    if (!rowHasError) {
      // 4. Duplicate Detection: match on externalPostId, otherwise on date + caption
      let isDuplicate = false;
      const idKey = rawExternalId ? `id:${rawExternalId.toLowerCase()}` : null;
      const contentKey = rawCaption ? `content:${parsedDate}|${rawCaption.toLowerCase()}` : null;

      if (idKey && seenKeys.has(idKey)) {
        isDuplicate = true;
      } else if (contentKey && seenKeys.has(contentKey)) {
        isDuplicate = true;
      }

      if (isDuplicate) {
        skippedDuplicates++;
        return; // Skip duplicate row
      }

      // Mark seen
      if (idKey) seenKeys.add(idKey);
      if (contentKey) seenKeys.add(contentKey);

      // Compute rates strictly from pure functions
      const metricInput = { reach, likes, comments, shares, saves };
      const engagementRate = calculateEngagementRate(metricInput);
      const shareRate = calculateShareRate(metricInput);
      const saveRate = calculateSaveRate(metricInput);

      validRows.push({
        id: `imported-${rowNum}-${Date.now()}`,
        externalPostId: rawExternalId || null,
        date: parsedDate,
        caption: rawCaption || '',
        topic,
        format,
        status: 'published',
        reach,
        impressions,
        views,
        likes,
        comments,
        shares,
        saves,
        hook,
        callToAction,
        profileVisits,
        follows,
        engagementRate,
        shareRate,
        saveRate,
        isSample: false,
      });
    }
  });

  return {
    validRows,
    errors,
    skippedDuplicates,
    totalParsed: rows.length,
    unmappedColumns,
  };
}

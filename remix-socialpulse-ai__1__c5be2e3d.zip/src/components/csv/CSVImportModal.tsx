import React, { useState } from 'react';
import {
  Upload,
  FileText,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  ArrowLeft,
  RotateCw,
  HelpCircle,
  Check,
} from 'lucide-react';
import {
  Modal,
  Button,
  Select,
  Badge,
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from '../ui/index.ts';
import {
  parseCSVText,
  guessColumnMapping,
  validateAndTransformCSV,
} from '../../lib/csvParser.ts';
import {
  CSVColumnMapping,
  CSVImportResult,
  PostMetricData,
} from '../../types/index.ts';
import {
  formatMetricPercentage,
  formatCount,
  calculateEngagementRate,
} from '../../lib/metrics.ts';
import { useApp } from '../../context/AppContext.tsx';

export type CSVStep = 'upload' | 'preview' | 'map' | 'validate' | 'confirm' | 'summary';

const STEPS: { id: CSVStep; label: string }[] = [
  { id: 'upload', label: 'Upload' },
  { id: 'preview', label: 'Preview' },
  { id: 'map', label: 'Map Columns' },
  { id: 'validate', label: 'Validate' },
  { id: 'confirm', label: 'Confirm' },
  { id: 'summary', label: 'Summary' },
];

export interface CSVImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete?: (importedPosts: Partial<PostMetricData>[]) => void;
}

const SAMPLE_CLEAN_CSV = `Date,Caption,Topic,Format,Reach,Impressions,Views,Likes,Comments,Shares,Saves
2026-07-28,"POV: First day posting Reels consistently from Delhi",Student Reality,reel,34500,42000,98000,6200,95,7100,520
2026-08-04,"Why your audio hook fails in the first 2 seconds",Viral Reels Timing,reel,48000,61000,145000,8900,120,9800,740
2026-08-11,"Behind the scenes: The 32M views editing timeline",Creator Hacks,carousel,22000,28500,n/a,3100,85,1400,2100
2026-08-19,"College student morning routine in Delhi vs Instagram reality",Youth Culture,reel,68000,89000,210000,12400,180,14200,980
2026-08-28,"Testing the 9 PM posting theory in Mumbai & Bangalore",Viral Reels Timing,reel,39000,49000,118000,7100,98,8200,610
2026-09-06,"5 sound-sync transitions that doubled our share rate",Creator Hacks,carousel,26000,34000,n/a,3800,110,1900,2850
2026-09-15,"When you edit for 6 hours and the audio gets copyright muted",Student Reality,reel,92000,125000,310000,17200,240,19800,1350
2026-09-24,"The 3-second visual rule that broke our account record",Retention Secrets,reel,115000,158000,420000,21500,310,24600,1820
2026-10-02,"Why 75% of our audience is young guys aged 18-24",Youth Culture,reel,54000,69000,165000,9800,145,11200,840
2026-10-10,"Sub-title color & pacing checklist for mobile screens",Creator Hacks,carousel,18500,24000,n/a,2600,74,980,1950
2026-10-18,"Friday night reel drop: How we got 2.3M shares",Viral Reels Timing,reel,142000,192000,510000,26800,380,31400,2240
2026-10-25,"32M Views in 90 Days: What we are changing next",Behind the Scenes,reel,88000,116000,285000,16100,220,18900,1420`;

const SAMPLE_BAD_CSV = `Date,Caption,Topic,Format,Reach,Impressions,Views,Likes,Comments,Shares,Saves
not-a-valid-date,"Broken date row test",AI Automation,reel,8500,10500,9800,420,55,110,380
2026-10-17,"Invalid metric test row",Prompt Engineering,carousel,not_a_number,15400,n/a,490,82,95,580
2026-10-19,"Negative likes error",Workflows,static_image,4200,5100,n/a,-50,18,12,65
2026-10-21,"Valid row alongside errors",Prompt Engineering,reel,14200,18900,16500,680,94,210,490
2026-10-21,"Valid row alongside errors",Prompt Engineering,reel,14200,18900,16500,680,94,210,490`;

export function CSVImportModal({ isOpen, onClose, onImportComplete }: CSVImportModalProps) {
  const [currentStep, setCurrentStep] = useState<CSVStep>('upload');
  const [fileName, setFileName] = useState<string>('');
  const [rawCSVText, setRawCSVText] = useState<string>('');
  const [headers, setHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<string[][]>([]);
  const [columnMapping, setColumnMapping] = useState<CSVColumnMapping>({
    date: '',
    caption: '',
    topic: '',
    format: '',
    reach: '',
    impressions: '',
    views: '',
    likes: '',
    comments: '',
    shares: '',
    saves: '',
  });
  const [validationResult, setValidationResult] = useState<CSVImportResult | null>(null);

  const resetAll = () => {
    setCurrentStep('upload');
    setFileName('');
    setRawCSVText('');
    setHeaders([]);
    setRawRows([]);
    setValidationResult(null);
  };

  const handleClose = () => {
    resetAll();
    onClose();
  };

  const handleFileProcess = (text: string, name: string) => {
    setFileName(name);
    setRawCSVText(text);
    const parsed = parseCSVText(text);
    setHeaders(parsed.headers);
    setRawRows(parsed.rows);
    const guessed = guessColumnMapping(parsed.headers);
    setColumnMapping(guessed);
    setCurrentStep('preview');
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result as string;
      handleFileProcess(content, file.name);
    };
    reader.readAsText(file);
  };

  const { importedPosts } = useApp();

  const handleRunValidation = () => {
    const result = validateAndTransformCSV(headers, rawRows, columnMapping, importedPosts);
    setValidationResult(result);
    setCurrentStep('validate');
  };

  const handleConfirmImport = () => {
    if (!validationResult) return;
    if (onImportComplete) {
      onImportComplete(validationResult.validRows);
    }
    setCurrentStep('summary');
  };

  const stepIndex = STEPS.findIndex((s) => s.id === currentStep);

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title="CSV Metrics Import"
      description="Parse, preview, map, and validate your historical Instagram content data locally."
      maxWidth="4xl"
      footer={
        <div className="flex items-center justify-between w-full">
          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4" />
            <span>Local in-browser parsing only. No remote storage or API transmission.</span>
          </div>
          <div className="flex items-center gap-2">
            {currentStep !== 'upload' && currentStep !== 'summary' && (
              <Button
                variant="outline"
                size="sm"
                leftIcon={<ArrowLeft className="w-3.5 h-3.5" />}
                onClick={() => {
                  if (currentStep === 'preview') setCurrentStep('upload');
                  else if (currentStep === 'map') setCurrentStep('preview');
                  else if (currentStep === 'validate') setCurrentStep('map');
                  else if (currentStep === 'confirm') setCurrentStep('validate');
                }}
              >
                Back
              </Button>
            )}

            {currentStep === 'preview' && (
              <Button
                variant="primary"
                size="sm"
                rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
                onClick={() => setCurrentStep('map')}
              >
                Continue to Mapping
              </Button>
            )}

            {currentStep === 'map' && (
              <Button
                variant="primary"
                size="sm"
                rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
                onClick={handleRunValidation}
              >
                Run Validation
              </Button>
            )}

            {currentStep === 'validate' && (
              <Button
                variant="primary"
                size="sm"
                rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
                onClick={() => setCurrentStep('confirm')}
                disabled={!validationResult || validationResult.validRows.length === 0}
              >
                Proceed to Confirm ({validationResult?.validRows.length ?? 0} valid rows)
              </Button>
            )}

            {currentStep === 'confirm' && (
              <Button
                variant="primary"
                size="sm"
                leftIcon={<Check className="w-3.5 h-3.5" />}
                onClick={handleConfirmImport}
              >
                Confirm Local Preview
              </Button>
            )}

            {currentStep === 'summary' && (
              <Button variant="primary" size="sm" onClick={handleClose}>
                Done & View Data
              </Button>
            )}
          </div>
        </div>
      }
    >
      {/* Stepper Progress Bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          {STEPS.map((step, idx) => {
            const isCompleted = idx < stepIndex;
            const isCurrent = idx === stepIndex;
            return (
              <div key={step.id} className="flex-1 flex flex-col items-center relative">
                {idx > 0 && (
                  <div
                    className={`absolute top-3.5 right-1/2 left-[-50%] h-0.5 -z-10 transition-colors ${
                      idx <= stepIndex ? 'bg-indigo-600 dark:bg-indigo-500' : 'bg-slate-200 dark:bg-slate-800'
                    }`}
                  />
                )}
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                    isCompleted
                      ? 'bg-indigo-600 text-white dark:bg-indigo-500'
                      : isCurrent
                      ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 ring-2 ring-indigo-600 dark:ring-indigo-400'
                      : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'
                  }`}
                >
                  {isCompleted ? <Check className="w-4 h-4" /> : idx + 1}
                </div>
                <span
                  className={`mt-1.5 text-[11px] font-medium hidden sm:block ${
                    isCurrent ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  {step.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Step 1: Upload */}
      {currentStep === 'upload' && (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 text-center hover:border-indigo-400 dark:hover:border-indigo-600 transition-colors bg-slate-50/50 dark:bg-slate-900/30">
            <Upload className="w-10 h-10 text-slate-400 dark:text-slate-500 mx-auto mb-3" />
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Select or Drop your Instagram CSV file
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
              Exported from Meta Business Suite, Hootsuite, or custom spreadsheet with metrics columns.
            </p>
            <div className="mt-4">
              <label className="inline-flex items-center justify-center px-4 py-2 text-xs font-medium rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer shadow-xs transition-colors">
                <span>Browse Files (.csv)</span>
                <input
                  type="file"
                  accept=".csv,text/csv"
                  className="hidden"
                  onChange={handleFileInputChange}
                />
              </label>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-100/70 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <h5 className="text-xs font-semibold text-slate-900 dark:text-slate-100 mb-2">
              Need a test file right now?
            </h5>
            <div className="flex flex-wrap items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                leftIcon={<FileText className="w-3.5 h-3.5 text-indigo-500" />}
                onClick={() => handleFileProcess(SAMPLE_CLEAN_CSV, 'sample_clean_metrics.csv')}
              >
                Load @irlvansh Verified CSV (12 posts - 90 Days)
              </Button>
              <Button
                variant="outline"
                size="sm"
                leftIcon={<AlertTriangle className="w-3.5 h-3.5 text-amber-500" />}
                onClick={() => handleFileProcess(SAMPLE_BAD_CSV, 'sample_with_validation_errors.csv')}
              >
                Load Test File with Validation Errors
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Step 2: Preview */}
      {currentStep === 'preview' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                File Preview: <span className="text-indigo-600 dark:text-indigo-400 font-mono">{fileName}</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Found {headers.length} columns and {rawRows.length} data rows. Showing initial sample.
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              leftIcon={<RotateCw className="w-3.5 h-3.5" />}
              onClick={resetAll}
            >
              Choose different file
            </Button>
          </div>

          <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden max-h-72 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12 text-center">#</TableHead>
                  {headers.map((h, i) => (
                    <TableHead key={i}>{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rawRows.slice(0, 5).map((row, rIdx) => (
                  <TableRow key={rIdx}>
                    <TableCell className="text-center font-mono text-xs text-slate-400">
                      {rIdx + 1}
                    </TableCell>
                    {headers.map((_, cIdx) => (
                      <TableCell key={cIdx} className="text-xs font-mono">
                        {row[cIdx] !== undefined && row[cIdx] !== '' ? row[cIdx] : <span className="text-slate-400 italic">n/a</span>}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* Step 3: Map Columns */}
      {currentStep === 'map' && (
        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Map CSV Headers to Instagram Metrics
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Confirm which columns match our delivery, engagement, and content attributes. Note: Reach is required for engagement rate calculation.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
            {Object.entries(columnMapping).map(([key, mappedValue]) => {
              const options = [
                { value: '', label: '-- Not Mapped / Unavailable --' },
                ...headers.map((h) => ({ value: h, label: h })),
              ];
              const isRequired = key === 'date';
              const isReach = key === 'reach';

              return (
                <div key={key} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold capitalize text-slate-800 dark:text-slate-200">
                      {key}
                    </span>
                    {isRequired && <Badge size="sm" variant="rose">Required</Badge>}
                    {isReach && <Badge size="sm" variant="violet">Rate Denominator</Badge>}
                  </div>
                  <Select
                    options={options}
                    value={mappedValue}
                    onChange={(e) =>
                      setColumnMapping({ ...columnMapping, [key]: e.target.value })
                    }
                  />
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Step 4: Validate */}
      {currentStep === 'validate' && validationResult && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Validation & Data Quality Report
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Scanned {validationResult.totalParsed} rows. Verified dates and numeric metric formats.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={validationResult.errors.length > 0 ? 'amber' : 'emerald'}>
                {validationResult.errors.length > 0
                  ? `${validationResult.errors.length} Errors Found`
                  : 'All Rows Passed'}
              </Badge>
              <Badge variant="violet">
                {validationResult.validRows.length} Valid Rows
              </Badge>
            </div>
          </div>

          {/* Errors list if any */}
          {validationResult.errors.length > 0 && (
            <div className="p-4 rounded-lg border border-amber-300 dark:border-amber-900/60 bg-amber-50/70 dark:bg-amber-950/20">
              <h5 className="text-xs font-semibold text-amber-900 dark:text-amber-200 flex items-center gap-1.5 mb-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                Validation Warnings & Excluded Rows:
              </h5>
              <div className="max-h-44 overflow-y-auto space-y-1.5 text-xs text-amber-800 dark:text-amber-300 pr-2">
                {validationResult.errors.map((err, i) => (
                  <div
                    key={i}
                    className="p-2 rounded bg-white/80 dark:bg-slate-900/80 border border-amber-200 dark:border-amber-900/40 flex items-start justify-between font-mono text-[11px]"
                  >
                    <span>
                      <strong className="text-amber-900 dark:text-amber-100">Row {err.row}:</strong> Field{' '}
                      <span className="font-semibold underline">{err.field}</span>: {err.message}
                    </span>
                    <Badge size="sm" variant="rose">Invalid: "{err.value}"</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Valid rows preview */}
          <div>
            <h5 className="text-xs font-semibold text-slate-800 dark:text-slate-200 mb-2">
              Valid Rows Ready for In-Memory Preview ({validationResult.validRows.length} rows):
            </h5>
            <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden max-h-56 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Format</TableHead>
                    <TableHead>Caption</TableHead>
                    <TableHead>Reach (Denom)</TableHead>
                    <TableHead>Eng. Rate</TableHead>
                    <TableHead>Save Rate</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {validationResult.validRows.slice(0, 5).map((row, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-mono text-xs">{row.date}</TableCell>
                      <TableCell>
                        <Badge size="sm" variant="neutral">{row.format}</Badge>
                      </TableCell>
                      <TableCell className="text-xs truncate max-w-xs">{row.caption}</TableCell>
                      <TableCell className="font-mono text-xs">{formatCount(row.reach)}</TableCell>
                      <TableCell className="font-mono text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                        {formatMetricPercentage(row.engagementRate)}
                      </TableCell>
                      <TableCell className="font-mono text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                        {formatMetricPercentage(row.saveRate)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>
      )}

      {/* Step 5: Confirm */}
      {currentStep === 'confirm' && validationResult && (
        <div className="space-y-4 text-center py-4">
          <div className="w-12 h-12 rounded-full bg-indigo-50 dark:bg-indigo-950 flex items-center justify-center mx-auto text-indigo-600 dark:text-indigo-400">
            <CheckCircle className="w-7 h-7" />
          </div>
          <h4 className="text-base font-semibold text-slate-900 dark:text-slate-100">
            Ready to load {validationResult.validRows.length} posts into preview?
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            This will populate your local session state for Dashboard, Analytics, and Content Studio. No backend database will be modified.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-lg mx-auto mt-4 text-left">
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Valid Posts</span>
              <span className="text-lg font-bold text-slate-900 dark:text-slate-100 font-mono">
                {validationResult.validRows.length}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
              <span className="text-[10px] text-amber-600 dark:text-amber-400 uppercase tracking-wider block">Skipped (Dupes)</span>
              <span className="text-lg font-bold text-amber-600 dark:text-amber-400 font-mono">
                {validationResult.skippedDuplicates}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
              <span className="text-[10px] text-rose-500 uppercase tracking-wider block">Errors</span>
              <span className="text-lg font-bold text-rose-600 dark:text-rose-400 font-mono">
                {validationResult.errors.length}
              </span>
            </div>
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Unmapped</span>
              <span className="text-lg font-bold text-slate-900 dark:text-slate-100 font-mono">
                {validationResult.unmappedColumns.length}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Step 6: Summary */}
      {currentStep === 'summary' && validationResult && (
        <div className="space-y-5 py-2">
          <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/70 dark:bg-emerald-950/30 flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-emerald-900 dark:text-emerald-100">
                Import Session Complete (Local Preview)
              </h4>
              <p className="text-xs text-emerald-800 dark:text-emerald-300 mt-0.5 leading-relaxed">
                Successfully loaded {validationResult.validRows.length} records into browser memory. {validationResult.skippedDuplicates > 0 ? `${validationResult.skippedDuplicates} duplicate records skipped.` : ''} Metric formulas have been evaluated using pure Reach denominators.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2">
              <h5 className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Calculated Engagement Summary
              </h5>
              <div className="text-xs space-y-1.5 text-slate-600 dark:text-slate-400">
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                  <span>Total Posts Loaded:</span>
                  <span className="font-semibold text-slate-900 dark:text-slate-100 font-mono">
                    {validationResult.validRows.length}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                  <span>Duplicates Skipped:</span>
                  <span className="font-semibold text-amber-600 dark:text-amber-400 font-mono">
                    {validationResult.skippedDuplicates}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                  <span>Reach Denominator Applied:</span>
                  <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                    Accounts Reached
                  </span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Unavailable Metrics Treated As:</span>
                  <span className="font-semibold font-mono">n/a (never 0)</span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2">
              <h5 className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Unmapped Columns
              </h5>
              <div className="flex flex-wrap gap-1.5">
                {validationResult.unmappedColumns.length > 0 ? (
                  validationResult.unmappedColumns.map((col, idx) => (
                    <Badge key={idx} size="sm" variant="neutral">
                      {col}
                    </Badge>
                  ))
                ) : (
                  <span className="text-xs text-slate-400 italic">None (all columns mapped)</span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
}
